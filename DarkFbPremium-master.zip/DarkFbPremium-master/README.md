# DarkFbPremium
<ul>
<li><code>pkg install git python2</code></li>
<li><code>pip2 install --upgrade pip</code></li>
<li><code>git clone https://github.com/J4rzz/DarkFbPremium</code></li>
<li><code>cd DarkFbPremium</code></li>
<li><code>pip2 install -r requirements</code></li>
<li><code>python2 DarkFB</code></li>
</ul>
<br />
<br />
